# utils
Some useful utilities.

`ts` - prints out a string suitable for a time stamp as `YYMMDD-hhmmss`.

`modtstamp` - adds or subtracts hours from a files timestamp, used to be
    useful when copying files across timezones, but possibly less
    useful these days.

`tabs2spaces/spaces2tabs` - is a wrapper for the commands `expand` and `unexpand`
    respectively.  The FILES are changed in place, and changes can easily
    be undone.

